package businesslayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public interface LogicLayer {
    void loginasAdmin(Connection connection) throws SQLException ;

    void loginasManager(Connection connection) throws SQLException ;


    void loginasCustomer(Connection connection) throws SQLException ;


    void createTable(Connection connection) throws SQLException ;

    void createUser(Connection connection) throws SQLException;

      void createAdmin(Connection connection) throws SQLException ;
}
