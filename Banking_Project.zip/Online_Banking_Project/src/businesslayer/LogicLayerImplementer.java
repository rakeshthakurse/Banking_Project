package businesslayer;


import roles.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class LogicLayerImplementer implements LogicLayer{


    public void loginasAdmin(Connection connection) throws SQLException {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your username: ");
        String username=sc.next();
        System.out.println("Enter your password: ");
        String password=sc.next();
        String selectAdminSQL = "SELECT username FROM admins WHERE username = ? AND password = ?";
        try (PreparedStatement statement = connection.prepareStatement(selectAdminSQL)) {
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                System.out.println("Logged in successfully.");
//                return resultSet.getString("username");
                Admin admin = new Admin();
                admin.startAdmin(username);

            } else {
                System.out.println("Not logged in. Invalid credentials.");
//                return null;
            }

        }
    }



    public void loginasManager(Connection connection) throws SQLException {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your username: ");
        String username=sc.next();
        System.out.println("Enter your password: ");
        String password=sc.next();
        String selectAdminSQL = "SELECT username FROM managers WHERE username = ? AND password = ?";
        try (PreparedStatement statement = connection.prepareStatement(selectAdminSQL)) {
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                System.out.println("Logged in successfully.");
//                return resultSet.getString("username");
                Manager md=new Manager();
                md.startManager(username);
            } else {
                System.out.println("Not logged in. Invalid credentials.");
//                return null;
            }

        }
    }



     public void loginasCustomer(Connection connection) throws SQLException {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your userID: ");
        String username=sc.next();
        System.out.println("Enter your password: ");
        String password=sc.next();
        String selectAdminSQL = "SELECT userID FROM accounts WHERE userID = ? AND password = ?";
        try (PreparedStatement statement = connection.prepareStatement(selectAdminSQL)) {
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                System.out.println("Logged in successfully.");
                ExistingCustomer ec=new ExistingCustomer();
                ec.startExistingCustomer(username);
            } else {
                System.out.println("Not logged in. Invalid credentials.");
            }

        }
    }





    public void createTable(Connection connection) throws SQLException {
        String createUserTableSQL = "CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(255), password VARCHAR(255))";
        String createAdminTableSQL = "CREATE TABLE IF NOT EXISTS admins (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(255), password VARCHAR(255))";

        try (PreparedStatement statement = connection.prepareStatement(createUserTableSQL)) {
            statement.executeUpdate();
        }

        try (PreparedStatement statement = connection.prepareStatement(createAdminTableSQL)) {
            statement.executeUpdate();
        }
    }

    public void createUser(Connection connection) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        String insertUserSQL = "INSERT INTO users (username, password) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(insertUserSQL)) {
            statement.setString(1, username);
            statement.setString(2, password);
            statement.executeUpdate();
        }

        System.out.println("User created successfully.");
    }

    public void createAdmin(Connection connection) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        String insertAdminSQL = "INSERT INTO admins (username, password) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(insertAdminSQL)) {
            statement.setString(1, username);
            statement.setString(2, password);
            statement.executeUpdate();
        }

        System.out.println("roles.Admin created successfully.");
    }
}
